//
//  ViewController.swift
//  DiscountApp
//
//  Created by Tummala,Nagarushyanth on 2/15/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var amountText: UITextField!
    
    
    @IBOutlet weak var discountField: UITextField!
    
    @IBOutlet weak var resultLabel: UILabel!
    
   
    @IBAction func submitButton(_ sender: UIButton) {
        
        var amount = Double(amountText.text!)
        var discount = Double(discountField.text!)
        
        var finalAmt = String(amount! - (amount!*discount!/100))
        
        resultLabel.text = ("Final Price after discount: \(finalAmt)")
        
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

