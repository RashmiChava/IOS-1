//
//  ViewController.swift
//  Garugu_Assignment02
//
//  Created by Garugu, Sai Shanmukh on 1/31/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var firstNameTextField: UITextField!
    
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    
    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        
        detailsLabel.text = "Details"
        let first_name = firstNameTextField.text!
        let last_name = lastNameTextField.text!
        fullnameNameLabel.text = "Full Name: \(first_name) \(last_name)"
        
        let f_initial = first_name.first!
        let l_initial = last_name.first!
        initialsLabel.text = "Initials: \(f_initial)\(l_initial)"
        
    }
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        
        detailsLabel.text = ""
        firstNameTextField.text = ""
        lastNameTextField.text = ""
        fullnameNameLabel.text = ""
        initialsLabel.text = ""
        
        firstNameTextField.becomeFirstResponder() == true
        
        
    }
    
    @IBOutlet weak var detailsLabel: UILabel!
    
    @IBOutlet weak var fullnameNameLabel: UILabel!
    
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

